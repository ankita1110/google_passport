module.exports = {

    'googleAuth' : {
        'clientID'      : '92572914111-hjifht1lqpdo76rev3jro49s2o4ttltm.apps.googleusercontent.com',
        'clientSecret'  : '5bwNoIor9UY7xshlpBH3qE0V',
        'callbackURL'   : 'http://localhost:4000/auth/google/callback'
    }

};
