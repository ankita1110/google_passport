var LocalStrategy = require('passport-local').Strategy;
var GoogleStrategy=require('passport-google-oauth').OAuth2Strategy;
var configAuth=require('./auth');
var express=require('express');
var passport=require('passport');
var app=express();
const session=require('express-session');
app.set('views',__dirname+'/views');
app.set('view engine','ejs');
var bp=require('body-parser');
app.use(bp.json());
app.use(session({secret:'user'}));
app.use(bp.urlencoded({ extended: true }));
app.use(passport.initialize());
app.use(passport.session())



    // used to serialize the user for the session
    passport.serializeUser(function(user, done) {
        done(null, user);
    });

    // used to deserialize the user
    passport.deserializeUser(function(user, done) {
        done(null, user);
    });

    passport.use(new GoogleStrategy({

            clientID        : "92572914111-hjifht1lqpdo76rev3jro49s2o4ttltm.apps.googleusercontent.com",
            clientSecret    : "5bwNoIor9UY7xshlpBH3qE0V",
            callbackURL     : "http://localhost:4000/auth/google/callback",

        },
        function(token, refreshToken, profile, done) {
            // console.log(profile);
            return done(null,profile);
            // make the code asynchronous
            // User.findOne won't fire until we have all our data back from Google

                // try to find the user based on their google id



        }));

app.get('/', (req, res)=> {
    res.render('index.ejs'); // load the index.ejs file
});

app.get('/profile',(req, res)=>{
    console.log('sending ',req.session.passport.user);
    res.render('profile.ejs',req.session.passport.user);
});

app.get('/logout',(req, res)=>{
    req.logout();
    res.redirect('/');
});

app.get('/auth/google', passport.authenticate('google', { scope : ['profile', 'email'] }));

app.get('/auth/google/callback',
    passport.authenticate('google', {
        successRedirect : '/profile',
        failureRedirect : '/'
    }));


function isLoggedIn(req, res, next) {
next()
    // if user is authenticated in the session, carry on
    if (req.isAuthenticated())
        return next();

    // if they aren't redirect them to the home page
    res.redirect('/');
}
app.listen(4000);
